/* ========================================
   📁 STRUCTURE DES FICHIERS :
   
   css/
   ├── main.css (ce fichier - importe tout)
   ├── variables.css
   ├── base.css
   ├── components.css
   └── responsive.css
   
   Dans votre HTML :
   <link rel="stylesheet" href="css/main.css">
======================================== */