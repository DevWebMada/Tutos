/* ========================================
   FICHIER 2/3 : js/utils.js
   Fonctions utilitaires réutilisables
======================================== */

// Smooth scroll pour les ancres
export function initSmoothScroll() {
  const links = document.querySelectorAll('a[href^="#"]');
  
  if (links.length === 0) {
    console.log('ℹ️ Aucun lien d\'ancre trouvé');
    return;
  }
  
  links.forEach(link => {
    link.addEventListener('click', function(e) {
      const href = this.getAttribute('href');
      
      // Ignorer les liens vides ou juste "#"
      if (!href || href === '#') return;
      
      e.preventDefault();
      const target = document.querySelector(href);
      
      if (target) {
        // Fermer le menu mobile si ouvert
        const nav = document.querySelector('.nav');
        if (nav && nav.classList.contains('open')) {
          nav.classList.remove('open');
          document.body.style.overflow = '';
        }
        
        // Scroll smooth vers la cible
        target.scrollIntoView({
          behavior: 'smooth',
          block: 'start'
        });
        
        // Mettre à jour l'URL sans recharger la page
        history.pushState(null, null, href);
      }
    });
  });
  
  console.log('✅ Smooth scroll initialisé');
}

// Détection du scroll pour header sticky avec effet
export function initScrollHeader() {
  const header = document.querySelector('.header');
  
  if (!header) {
    console.warn('⚠️ Header introuvable');
    return;
  }
  
  let lastScroll = 0;
  
  window.addEventListener('scroll', function() {
    const currentScroll = window.pageYOffset;
    
    // Ajouter classe "scrolled" après 50px
    if (currentScroll > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
    
    // Cache le header quand on scroll vers le bas (optionnel)
    // Décommentez si vous voulez cette fonctionnalité
    /*
    if (currentScroll > lastScroll && currentScroll > 100) {
      header.style.transform = 'translateY(-100%)';
    } else {
      header.style.transform = 'translateY(0)';
    }
    */
    
    lastScroll = currentScroll;
  });
  
  console.log('✅ Scroll header initialisé');
}

// Animation au scroll (fade-in pour les éléments)
export function initScrollAnimations() {
  const elements = document.querySelectorAll('.fade-in');
  
  if (elements.length === 0) {
    console.log('ℹ️ Aucun élément .fade-in trouvé');
    return;
  }
  
  // Observer pour détecter quand les éléments entrent dans le viewport
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        // Optionnel : arrêter d'observer après l'animation
        observer.unobserve(entry.target);
      }
    });
  }, {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
  });
  
  elements.forEach(el => observer.observe(el));
  
  console.log('✅ Animations scroll initialisées');
}

// Gestion des formulaires (validation basique)
export function initFormValidation() {
  const forms = document.querySelectorAll('form[data-validate]');
  
  if (forms.length === 0) {
    console.log('ℹ️ Aucun formulaire à valider');
    return;
  }
  
  forms.forEach(form => {
    form.addEventListener('submit', function(e) {
      e.preventDefault();
      
      // Validation basique
      const inputs = form.querySelectorAll('input[required], textarea[required]');
      let isValid = true;
      
      inputs.forEach(input => {
        if (!input.value.trim()) {
          isValid = false;
          input.classList.add('error');
        } else {
          input.classList.remove('error');
        }
      });
      
      if (isValid) {
        console.log('✅ Formulaire valide');
        // Ici vous pouvez ajouter l'envoi AJAX
        form.submit();
      } else {
        console.warn('⚠️ Veuillez remplir tous les champs');
      }
    });
  });
  
  console.log('✅ Validation formulaires initialisée');
}

// Détection du thème sombre/clair (bonus)
export function initThemeToggle() {
  const themeToggle = document.querySelector('[data-theme-toggle]');
  
  if (!themeToggle) {
    console.log('ℹ️ Pas de toggle de thème');
    return;
  }
  
  // Récupérer le thème sauvegardé
  const currentTheme = localStorage.getItem('theme') || 'light';
  document.documentElement.setAttribute('data-theme', currentTheme);
  
  themeToggle.addEventListener('click', function() {
    const theme = document.documentElement.getAttribute('data-theme');
    const newTheme = theme === 'light' ? 'dark' : 'light';
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
    
    console.log(`🎨 Thème changé : ${newTheme}`);
  });
  
  console.log('✅ Toggle thème initialisé');
}