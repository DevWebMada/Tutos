console.log('main.js chargé !');
console.log('test 1, 2, 3...');





/* ========================================
   FICHIER 3/3 : js/main.js
   Point d'entrée principal
======================================== */

// Import des modules
import { initMobileMenu } from './menu.js';
import { 
  initSmoothScroll, 
  initScrollHeader, 
  initScrollAnimations,
  initFormValidation,
  initThemeToggle 
} from './utils.js';

// Attendre que le DOM soit complètement chargé
document.addEventListener('DOMContentLoaded', function() {
  
  console.log('🚀 Initialisation du site...');
  
  // === FONCTIONNALITÉS ESSENTIELLES ===
  initMobileMenu();        // Menu burger mobile
  
  // === FONCTIONNALITÉS OPTIONNELLES ===
  // Décommentez celles que vous voulez utiliser :
  
  initSmoothScroll();      // Défilement fluide pour les ancres
  initScrollHeader();      // Effet au scroll du header
  // initScrollAnimations();  // Animations d'apparition au scroll
  // initFormValidation();    // Validation des formulaires
  // initThemeToggle();       // Mode sombre/clair
  
  console.log('✅ Site prêt !');
});

// Gestion du redimensionnement de fenêtre (debounced)
let resizeTimer;
window.addEventListener('resize', function() {
  clearTimeout(resizeTimer);
  resizeTimer = setTimeout(function() {
    console.log('📐 Fenêtre redimensionnée : ' + window.innerWidth + 'px');
    // Ajoutez ici du code à exécuter après le resize
  }, 250);
});

// Gestion des erreurs JavaScript globales
window.addEventListener('error', function(e) {
  console.error('❌ Erreur JavaScript :', e.message);
});

// Performance : log du temps de chargement
window.addEventListener('load', function() {
  const loadTime = performance.timing.domContentLoadedEventEnd - performance.timing.navigationStart;
  console.log(`⚡ Page chargée en ${loadTime}ms`);
});