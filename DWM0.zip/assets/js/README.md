/* ========================================
   📁 STRUCTURE DES FICHIERS JAVASCRIPT
   
   js/
   ├── main.js (ce fichier - point d'entrée)
   ├── menu.js (gestion du menu mobile)
   └── utils.js (fonctions utilitaires)
   
   Dans votre HTML (avant </body>) :
   <script type="module" src="js/main.js"></script>
======================================== */