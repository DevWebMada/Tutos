


/* ========================================
   FICHIER 1/3 : js/menu.js
   Gestion du menu mobile
======================================== */

export function initMobileMenu() {
  const menuToggle = document.querySelector('.menu-toggle');
  const nav = document.querySelector('.nav');
  
  // Vérifier que les éléments existent
  if (!menuToggle || !nav) {
    console.warn('⚠️ Menu mobile : éléments introuvables');
    return;
  }
  
  // Toggle du menu au clic sur le bouton
  menuToggle.addEventListener('click', function(e) {
    e.stopPropagation();
    toggleMenu();
  });
  
  // Fermer le menu au clic sur un lien
  const navLinks = document.querySelectorAll('.nav a');
  navLinks.forEach(link => {
    link.addEventListener('click', function() {
      closeMenu();
    });
  });
  
  // Fermer le menu en cliquant à l'extérieur
  document.addEventListener('click', function(e) {
    if (!nav.contains(e.target) && !menuToggle.contains(e.target)) {
      closeMenu();
    }
  });
  
  // Fermer le menu lors du redimensionnement (passage desktop)
  window.addEventListener('resize', function() {
    if (window.innerWidth > 768 && nav.classList.contains('open')) {
      closeMenu();
    }
  });
  
  // Fonction pour ouvrir/fermer le menu
  function toggleMenu() {
    nav.classList.toggle('open');
    
    if (nav.classList.contains('open')) {
      menuToggle.innerHTML = '✕';
      menuToggle.setAttribute('aria-label', 'Fermer le menu');
      document.body.style.overflow = 'hidden'; // Bloquer le scroll
    } else {
      menuToggle.innerHTML = '☰';
      menuToggle.setAttribute('aria-label', 'Ouvrir le menu');
      document.body.style.overflow = '';
    }
  }
  
  // Fonction pour fermer le menu
  function closeMenu() {
    nav.classList.remove('open');
    menuToggle.innerHTML = '☰';
    menuToggle.setAttribute('aria-label', 'Ouvrir le menu');
    document.body.style.overflow = '';
  }
  
  console.log('✅ Menu mobile initialisé');
}





